package com.louaraya.macrame.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.louaraya.macrame.data.remote.ProductDto
import com.louaraya.macrame.data.remote.RemoteDataSources
import com.louaraya.macrame.data.remote.RequestDto
import com.louaraya.macrame.data.remote.WeatherResponse
import com.louaraya.macrame.data.remote.display
import com.louaraya.macrame.domain.RequestStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class BackendUiState(
    val catalogOnline: Boolean = false,
    val requestsOnline: Boolean = false,
    val weather: String = "Consultando clima…",
    val products: List<ProductDto> = emptyList(),
    val requests: List<RequestDto> = emptyList(),
    val loading: Boolean = false,
    val message: String? = null,
    val error: String? = null
)

/** Estado de la pantalla que demuestra la integración con los microservicios y la API externa. */
class BackendViewModel(private val remote: RemoteDataSources) : ViewModel() {
    private val _state = MutableStateFlow(BackendUiState())
    val state: StateFlow<BackendUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch { refreshSuspend() }
    }

    private suspend fun refreshSuspend() {
        _state.update { it.copy(loading = true, error = null, message = null) }

        val catalogOk = remote.catalogHealth().isSuccess
        val requestsOk = remote.requestHealth().isSuccess
        val products = remote.getProducts().getOrDefault(emptyList())
        val requests = remote.getRequests().getOrDefault(emptyList())
        val weather = remote.weather().getOrNull()?.display() ?: "Clima no disponible (sin conexión)"

        _state.update {
            it.copy(
                catalogOnline = catalogOk, requestsOnline = requestsOk,
                products = products, requests = requests, weather = weather,
                loading = false,
                error = if (!catalogOk || !requestsOk)
                    "Los microservicios no responden. Revisa que estén encendidos en 8081 y 8082."
                else null
            )
        }
    }

    /** CREATE desde la interfaz. */
    fun createDemoProduct() {
        action("Producto de prueba creado en catalog-service") {
            val next = (_state.value.products.maxOfOrNull { it.id } ?: 0L) + 1
            val product = ProductDto(
                code = "LAM-%04d".format(next + 100),
                name = "Pieza API ${next + 100}",
                description = "Producto creado desde la app con Retrofit.",
                category = "Interiores", widthCm = 80, heightCm = 60,
                material = "Algodón natural", priceClp = 45000, stock = 5, active = true
            )
            remote.createProduct(product)
        }
    }

    /** UPDATE desde la interfaz. */
    fun bumpPrice(product: ProductDto) {
        action("Precio actualizado en catalog-service") {
            remote.updateProduct(product.id, product.copy(priceClp = product.priceClp + 1000))
        }
    }

    /** DELETE desde la interfaz. */
    fun deleteProduct(id: Long) {
        action("Producto eliminado en catalog-service") { remote.deleteProduct(id) }
    }

    /** UPDATE de estado desde la interfaz (PATCH). */
    fun advanceStatus(request: RequestDto) {
        val next = when (request.status) {
            RequestStatus.PENDIENTE -> RequestStatus.CONFIRMADO
            RequestStatus.CONFIRMADO -> RequestStatus.ENTREGADO
            else -> RequestStatus.PENDIENTE
        }
        action("Solicitud actualizada en request-service") {
            remote.updateRequestStatus(request.id, next)
        }
    }

    /** CREATE de solicitud desde la interfaz. */
    fun createDemoRequest() {
        action("Solicitud de prueba creada en request-service") {
            remote.createRequest(
                RequestDto(
                    userId = 2L, clientName = "Cliente API", eventType = "Matrimonio",
                    widthCm = 150, heightCm = 120, material = "Algodón natural",
                    colors = "Crudo,Salvia", requiredDate = System.currentTimeMillis(),
                    notes = "Solicitud creada desde la app con Retrofit.",
                    status = RequestStatus.PENDIENTE
                )
            )
        }
    }

    private fun action(successMessage: String, block: suspend () -> Result<*>) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, message = null, error = null) }
            val result = runCatching { block() }
            val remoteResult = result.getOrNull()
            when {
                remoteResult is Result<*> && remoteResult.isFailure -> _state.update {
                    it.copy(
                        loading = false,
                        error = remoteResult.exceptionOrNull()?.message ?: "No se pudo completar la operación"
                    )
                }
                result.isFailure -> _state.update {
                    it.copy(loading = false, error = result.exceptionOrNull()?.message ?: "Error inesperado")
                }
                else -> {
                    refreshSuspend()
                    _state.update { it.copy(message = successMessage) }
                }
            }
        }
    }
}

/** Expuesto para pruebas unitarias del mapeo de la API externa. */
fun weatherText(response: WeatherResponse): String = response.display()
