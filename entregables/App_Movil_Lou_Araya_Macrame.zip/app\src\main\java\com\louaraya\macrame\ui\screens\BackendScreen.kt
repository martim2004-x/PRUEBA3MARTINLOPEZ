package com.louaraya.macrame.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.louaraya.macrame.ui.components.AppCard
import com.louaraya.macrame.ui.components.Pill
import com.louaraya.macrame.ui.components.PrimaryButton
import com.louaraya.macrame.ui.components.RoundIconButton
import com.louaraya.macrame.ui.components.SectionTitle
import com.louaraya.macrame.ui.components.SoftButton
import com.louaraya.macrame.ui.components.StatusPill
import com.louaraya.macrame.ui.theme.MacrameColors
import com.louaraya.macrame.ui.viewmodel.BackendViewModel
import com.louaraya.macrame.ui.viewmodel.macrameViewModel
import com.louaraya.macrame.util.Formatters

/** Pantalla de evidencia visual de la integración microservicios y api */
@Composable
fun BackendScreen(onBack: () -> Unit) {
    val vm = macrameViewModel { BackendViewModel(it.remote) }
    val state by vm.state.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize()) {
        com.louaraya.macrame.ui.components.ScreenHeader(
            title = "Integración y APIs",
            subtitle = "Microservicios Spring Boot + Open-Meteo",
            onBack = onBack,
            actions = {
                RoundIconButton(Icons.Rounded.Refresh, "Actualizar", vm::refresh)
            }
        )

        if (state.loading) {
            Row(
                Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.Center
            ) { CircularProgressIndicator(color = MacrameColors.Forest) }
        }

        state.error?.let { ErrorBanner(it) }
        state.message?.let { MessageBanner(it) }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { StatusRow(state.catalogOnline, state.requestsOnline) }

            item {
                AppCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Rounded.Public, null, tint = MacrameColors.Forest)
                            Text("API externa · Open-Meteo", style = MaterialTheme.typography.titleMedium, color = MacrameColors.Ink)
                        }
                        Text("Clima actual en Santiago, Chile", style = MaterialTheme.typography.bodySmall, color = MacrameColors.Muted)
                        Text(state.weather, style = MaterialTheme.typography.titleLarge, color = MacrameColors.Forest)
                    }
                }
            }

            item { SectionTitle("Productos · catalog-service (CRUD)") }

            item {
                PrimaryButton(
                    text = "Crear producto de prueba",
                    onClick = vm::createDemoProduct,
                    icon = Icons.Rounded.Add,
                    enabled = !state.loading
                )
            }

            items(state.products, key = { it.id }) { product ->
                AppCard {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "${product.code} · ${product.name}",
                                style = MaterialTheme.typography.titleSmall, color = MacrameColors.Ink,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Pill(if (product.active) "Activo" else "Inactivo", MacrameColors.SageTint, MacrameColors.Forest)
                        }
                        Text(
                            "${Formatters.price(product.priceClp)} · ${product.category} · Stock ${product.stock}",
                            style = MaterialTheme.typography.bodySmall, color = MacrameColors.Muted
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { vm.bumpPrice(product) }) {
                                Icon(Icons.Rounded.Edit, null, modifier = Modifier.padding(end = 4.dp))
                                Text("Subir precio", color = MacrameColors.Forest)
                            }
                            TextButton(onClick = { vm.deleteProduct(product.id) }) {
                                Icon(Icons.Rounded.Delete, null, modifier = Modifier.padding(end = 4.dp))
                                Text("Eliminar", color = MacrameColors.Error)
                            }
                        }
                    }
                }
            }

            item { SectionTitle("Solicitudes · request-service (CRUD)") }

            item {
                SoftButton(
                    text = "Crear solicitud de prueba",
                    onClick = vm::createDemoRequest,
                    icon = Icons.Rounded.Add,
                    enabled = !state.loading
                )
            }

            items(state.requests, key = { it.id }) { request ->
                AppCard {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "SOL-%04d · %s".format(request.id, request.clientName),
                                style = MaterialTheme.typography.titleSmall, color = MacrameColors.Ink,
                                modifier = Modifier.weight(1f)
                            )
                            StatusPill(request.status)
                        }
                        Text(
                            "${request.eventType} · ${Formatters.dimensions(request.widthCm, request.heightCm)}",
                            style = MaterialTheme.typography.bodySmall, color = MacrameColors.Muted
                        )
                        TextButton(onClick = { vm.advanceStatus(request) }) {
                            Icon(Icons.Rounded.Edit, null, modifier = Modifier.padding(end = 4.dp))
                            Text("Avanzar estado", color = MacrameColors.Forest)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusRow(catalogOnline: Boolean, requestsOnline: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Pill(
            if (catalogOnline) "Catálogo ● en línea" else "Catálogo ● sin conexión",
            if (catalogOnline) MacrameColors.SuccessTint else MacrameColors.ErrorTint,
            if (catalogOnline) MacrameColors.Success else MacrameColors.Error,
            Modifier.weight(1f)
        )
        Pill(
            if (requestsOnline) "Solicitudes ● en línea" else "Solicitudes ● sin conexión",
            if (requestsOnline) MacrameColors.SuccessTint else MacrameColors.ErrorTint,
            if (requestsOnline) MacrameColors.Success else MacrameColors.Error,
            Modifier.weight(1f)
        )
    }
}

@Composable
private fun ErrorBanner(text: String) {
    AppCard(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Rounded.Cloud, null, tint = MacrameColors.Error)
            Text(text, style = MaterialTheme.typography.bodySmall, color = MacrameColors.Error)
        }
    }
}

@Composable
private fun MessageBanner(text: String) {
    AppCard(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
        Text(text, style = MaterialTheme.typography.bodySmall, color = MacrameColors.Success, modifier = Modifier.padding(12.dp))
    }
}
